/**
 * 
 */


/**
 * <p>
 * Copyright: Copyright (c) 2018
 * </p>
 * <p>
 * Organization: ICT / TU Wien
 * </p>
 *  
 * @author Roland Beckert
 * @version 1.0 
 *  
 * Klasse f�r Tresore mit LCD
 * 
 */
public class LCDTresor extends Tresor {

	/**
	 * Konstruktor: 
	 * Initialisierung mit new LCDTresorZugriff. 	 
	 */
	public LCDTresor() {
		super(new LCDTresorZugriff() );
	}

	/**
	 * Ausgabe des Status durch displayStatusLCD(...) von ITresorZugriff
	 */
	@Override
	public void displayStatus(boolean status, String text) {
		
		// Aufruf der Implementierung in LCDTresorZugriff
		this.getTresorZugriff().displayStatusLCD(status, text);
	}


}
