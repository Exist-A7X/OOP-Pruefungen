

/**
 * <p>
 * Copyright: Copyright (c) 2018
 * </p>
 * <p>
 * Organization: ICT / TU Wien
 * </p>
 * 
 * @author Roland Beckert
 * @version 1.0 
 *  
 * TestMain Test-Klasse zum Testen der im Package vorhandenen Konstruktoren und Methoden mittels Main Methode

 *
 */
public class TestMain {

	// Main Methode
	/**
	 * Die Methode wird beim Aufruf des Programms gestartet
	 * 
	 * @param args In diesem String[] werden die Kommando-Zeilenparameter �bergeben
	 */
	public static void main(String[] args) {
		
		// Ein Tresor mit LED
		System.out.println();
		System.out.println("*** Ein Tresor mit LED ***");
		
		System.out.println(); System.out.println("* new LEDTresor()... mit Eingabe von Initialisierung-KeyCode, z.B. 1234");
		Tresor tresor = new LEDTresor(); 	
		
		System.out.println(); System.out.println("* Ausgabe von displayStatus(...):");
		tresor.displayStatus(tresor.isOpen(), "OPEN");
		
		// Tresor �ffnen mit falschem Code
		System.out.println(); System.out.println("* Tresor �ffnen mit falschem Code (z.B. 1111)...");
		tresor.unlockWithCode();
		
		System.out.println(); System.out.println("* Ausgabe von displayStatus(...):");
		tresor.displayStatus(tresor.isOpen(), "OPEN");

		// Tresor �ffnen mit richtigem Code
		System.out.println(); System.out.println("* Tresor �ffnen mit richtigem Code (1234)...");
		tresor.unlockWithCode();
		
		System.out.println(); System.out.println("* Ausgabe von displayStatus(...):");
		tresor.displayStatus(tresor.isOpen(), "OPEN");

		// Tresor schliessen
		System.out.println(); System.out.println("* Tresor schliessen...");
		tresor.lock();
		
		System.out.println(); System.out.println("* Ausgabe von displayStatus(...):");
		tresor.displayStatus(tresor.isOpen(), "OPEN");
		
		// Eine Tresor mit LCD
		System.out.println(); System.out.println("*** Ein Tresor mit LCD ***");
		
		System.out.println(); System.out.println("* new LCDTresor()... mit Eingabe von Initialisierung-KeyCode, z.B. 4321");
		tresor = new LCDTresor();		
		
		System.out.println(); System.out.println("* Ausgabe von displayStatus(...):");
		tresor.displayStatus(tresor.isOpen(), "OPEN");
		
		// Tresor �ffnen mit falschem Code
		System.out.println(); System.out.println("* Tresor �ffnen mit falschem Code (z.B. 1234)...");
		tresor.unlockWithCode();
		
		System.out.println(); System.out.println("* Ausgabe von displayStatus(...):");
		tresor.displayStatus(tresor.isOpen(), "OPEN");

		// Tresor �ffnen mit richtigem Code
		System.out.println(); System.out.println("* Tresor �ffnen mit richtigem Code (4321)...");
		tresor.unlockWithCode();
		
		System.out.println(); System.out.println("* Ausgabe von displayStatus(...):");
		tresor.displayStatus(tresor.isOpen(), "OPEN");

		// Tresor schliessen
		System.out.println(); System.out.println("* Tresor schliessen...");
		tresor.lock();
		
		System.out.println(); System.out.println("* Ausgabe von displayStatus(...):");
		tresor.displayStatus(tresor.isOpen(), "OPEN");
		
		System.out.println(); System.out.println("*** THE END ***");
		
		
	}

}
