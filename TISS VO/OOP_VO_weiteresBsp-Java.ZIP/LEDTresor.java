/**
 * 
 */


/**
 * <p>
 * Copyright: Copyright (c) 2018
 * </p>
 * <p>
 * Organization: ICT / TU Wien
 * </p>
 *  
 * @author Roland Beckert
 * @version 1.0
 * 
 * Klasse f�r Tresore (ohne LCD aber) mit LED
 * 
 */
public class LEDTresor extends Tresor {
	
	/**
	 * Konstruktor: 
	 * Initialisierung mit new LEDTresorZugriff(). 
	 */
	public LEDTresor() {
		super(new LEDTresorZugriff());
	}

	/**
	 * Ausgabe des Status durch displayStatusLED(...) von ITresorZugriff
	 */
	@Override
	public void displayStatus(boolean status, String text) {
		
		// Aufruf der Implementierung in LEDTresorZugriff
		this.getTresorZugriff().displayStatusLED(status);
	}



}
