

import java.util.Scanner;


/**
 * <p>
 * Copyright: Copyright (c) 2018
 * </p>
 * <p>
 * Organization: ICT / TU Wien
 * </p>
 * 
 * @author Roland Beckert
 * @version 1.0 
 *  
 * LEDTresorZugriff ist eine Implementierung fuer alle 
 * Zugriffsmethoden zu den Tresor-Komponenten Display, Numpad und Door
 *
 */

public class LEDTresorZugriff implements ITresorZugriff{
	
	// Real erfolgt hier entweder die Einbindung des HW-nahen Codes �ber das Java Native Interface (JNI)
	// oder eine Java-basierte Schnittstelle wie z.B. Pi4J (siehe http://pi4j.com/)
	
	@Override
	public void displayStatusLCD(boolean status, String text) {
		// TODO Auto-generated method stub
		
		// keine Implementierung, da nicht verwendet!
	}
	
	@Override
	public void displayStatusLED(boolean status) {
		// TODO Auto-generated method stub
		
		// Stub mit Test-Implementierung: Ausgabe von status auf System.out
		System.out.println(">>>ComponentLED>>> " + status);

	}
	
	@Override
	public int getKeyCode() {
		// TODO Auto-generated method stub
		
		// Stub mit Test-Implementierung: Eingabe einer Dezimalzahl n von System.in und R�ckgabe von n
		Scanner reader = new Scanner(System.in);  // Reading from System.in
		
		System.out.println(">>>ComponentNumpad>>> Enter 4-digit decimal KeyCode + push Enter-Key: ");
		int n = reader.nextInt(); // Scans the next token of the input as an int.
		
		//once finished
		//reader.close();

		return n;
	}
	
	@Override
	public boolean unlockDoor() {
		// TODO Auto-generated method stub
		
		// Stub mit Test-Implementierung: R�ckgabe true
		return true;
	}

	@Override
	public boolean lockDoor() {
		// TODO Auto-generated method stub
		
		// Stub mit Test-Implementierung: R�ckgabe true
		return true;
	}

}
