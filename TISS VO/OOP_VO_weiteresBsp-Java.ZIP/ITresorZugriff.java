

/**
 * <p>
 * Copyright: Copyright (c) 2018
 * </p>
 * <p>
 * Organization: ICT / TU Wien
 * </p>
 * 
 * @author Roland Beckert
 * @version 1.0 
 *  
 * ITresorZugriff ist ein Interface fuer alle Zugriffsmethoden zu den 
 * Tresor-Komponenten Display, Numpad und Door
 */
public interface ITresorZugriff {
	
	/**
	 * HW-m��ige Ausgabe von status und eventuell text am Display 
	 * des jeweiligen Tresors:
	 */
	void displayStatusLCD(boolean status, String text);
	void displayStatusLED(boolean status);
	
	/**
	 * Holen des KeyCode vom angeschlossenen NumPad und 
	 * R�ckgabe der eingegebene Dezimalzahl als @return int:
	 */
	int getKeyCode();
	
	/**
	 * Entsperren der HW der T�r mit R�ckgabe des Ergebnisses 
	 * der Operation (true/false) als @return boolean:

	 */
	boolean unlockDoor();
	
	/**
	 * Sperren der HW der T�r mit R�ckgabe des Ergebnisses 
	 * der Operation (true/false) als @return boolean: 
	 */
	boolean lockDoor();
		
}
