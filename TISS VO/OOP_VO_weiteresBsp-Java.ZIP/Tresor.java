/**
 * 
 */


/**
 * <p>
 * Copyright: Copyright (c) 2018
 * </p>
 * <p>
 * Organization: ICT / TU Wien
 * </p>
 * 
 * @author Roland Beckert
 * @version 1.0 
 *  
 * Tresor ist eine abstrakte Klasse und die Mutter aller Tresorprodukte einer Firma
 *
 */
public abstract class Tresor {
	
	/* keyCode: (vierstellige) Dezimalzahl zum �ffnen des Tresors */
	private int keyCode = 1111;
	
	/* isOpen: stellt den �ffnungszustand der T�r dar (true = offen / false = geschlossen) */
	private boolean isOpen = false;
	
	/* tresorZugriff: definiert die aktuellen Komponenten und deren Zugriffs-Methoden */
	private ITresorZugriff tresorZugriff = null;

	
	/**
	 * Alternativer Konstruktor: 
	 * Initialisierung von tresorZugriff und keyCode mit @param tresorZugriff und getKeyCode(). 
	 */
	public Tresor(ITresorZugriff tresorZugriff) {
		
		this.tresorZugriff = tresorZugriff;
		
		// keyCode wird vom angeschlossenen NumPad geholt
		this.keyCode = this.tresorZugriff.getKeyCode();
	
	}
	
	/**
	 * Ausgabe von @params status und text. 
	 * Diese abstrakte Methode wird in den erbenden Klassen implementiert
	 * (Implementierung ist abh�ngig von der Tresor-Variante).
	 */
	public abstract void displayStatus(boolean status, String text);
		
	/**
	 * Setter: 
	 * Neuer keyCode wird vom NumPad geholt
	 */
	public void setKeyCode() {
		
		this.keyCode = this.getTresorZugriff().getKeyCode();
				
	}
	
	/**
	 * Methoden-Funktionalit�t: 
	 * Entriegeln des Tresors nach erfolgreichem Check von keyCode; 
	 * dazu keyCode vom Numpad holen, Check ob ident mit initialem keyCode, 
	 * wenn erfolgreich unlockDoor() und Setzen von isOpen.
	 */
	public void unlockWithCode(){
		
		if (this.keyCode == this.getTresorZugriff().getKeyCode()) {
			
			// keyCode OK		
			this.isOpen = this.getTresorZugriff().unlockDoor();
		
		}
	}
	
	/**
	 * Methoden-Funktionalit�t: 
	 * Verriegeln des Tresors mit lockDoor() und Setzen von isOpen.
	 */
	public void lock(){
		
		this.isOpen = ! this.getTresorZugriff().lockDoor();
	}
	
	/**
	 * Getter: 
	 * R�ckgabe von isOpen (offen/geschlossen) als @return boolean.
	 */
	public boolean isOpen() {
		
		return this.isOpen;
	}
	

	/**
	 * R�ckgabe von tresorZugriff als @return ITresorZugriff.
	 */
	public ITresorZugriff getTresorZugriff() {
		return this.tresorZugriff;
	}
	
	/**
	 * Setzen von tresorZugriff auf @param ITresorZugriff
	 */
	public void setTresorZugriff(ITresorZugriff tresorZugriff) {
		this.tresorZugriff = tresorZugriff;
	}

}
